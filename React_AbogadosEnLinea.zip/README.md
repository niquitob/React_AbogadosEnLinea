# ReactJS Real Time list 
### Via NodeJS RESTful API for RethinkDB with Express and Web Sockets with Socket.IO
###### by César Antón Dorantes @ reicek
